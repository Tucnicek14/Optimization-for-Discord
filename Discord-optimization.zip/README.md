Hello!
This a little project i made for debloating and optimizing discord a bit.
I made this in less than an hour. Its nothing crazy but it can really make a difference! Just open the "discord-optimize.bat" file and let it run.
Unfortunetally it only works on Windows..


I will give you a guide how to optimize Discord even more in the app! (Should work in Linux and Mac)
Go to "User Settings" -> "Accessibility" and turn on "Reduce Motion" and turn off "Automaticall play GIFs when Discord is focused" 
and "Play animated emoji".
Then set stickers to "Never animate" or "Animate on interactions".
After go to the "Advanced" tab and turn off "Hardware acceleration".
You can customize this. It just comes to personal preference. It is your choice if you want to do this.


I got an idea to do this from watching a video from Panjno and made this automatic. (https://www.youtube.com/watch?v=XOfktAGjrUQ)
Everything can be reverted just by reinstalling Discord.
Now enjoy!
